
R version 4.5.1 (2025-06-13) -- "Great Square Root"
Copyright (C) 2025 The R Foundation for Statistical Computing
Platform: aarch64-apple-darwin20

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

[R.app GUI 1.82 (8536) aarch64-apple-darwin20]

> #Exercise
> #1
> setwd("/Users/nimani/Library/CloudStorage/OneDrive-SriLankaInstituteofInformationTechnology/2nd YR/Sem 01/PS IT2120/Labs/Lab 05")
> Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")
> 
> #2
> names(Delivery_Times) <- c("Time")
> histogram <- hist(main = "Histogram for Delivery Time", Delivery_Times$Time, breaks = seq(20, 70, length=10),right = FALSE)
> 
> #4
> breaks <- round(histogram$breaks)
> freq   <- histogram$counts
> mids   <- histogram$mids 
> 
> classes <- c()
> for(i in 1:(length(breaks)-1)){
+   classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
+ }
> 
> cum.freq <- cumsum(freq)
> new <- c()
> for(i in 1:length(breaks)){
+   if(i==1){
+     new[i] = 0
+   } else {
+     new[i] = cum.freq[i-1]
+   }
+ }
> plot(breaks, new, type = 'l', main = "Cumalative Frequency Polygon for Delivery Times", xlab = "Delivery Time", ylab = "Cumulative Frequency", ylim = c(0,max(cum.freq)))
> cbind(Upper = breaks, CumFreq = new)
      Upper CumFreq
 [1,]    20       0
 [2,]    26       2
 [3,]    31       5
 [4,]    37      11
 [5,]    42      20
 [6,]    48      26
 [7,]    53      29
 [8,]    59      35
 [9,]    64      38
[10,]    70      40
> 